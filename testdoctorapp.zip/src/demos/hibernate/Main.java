package demos.hibernate;



import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import demos.hibernate.model.Product;
import demos.hibernate.util.HibernateUtil;

public class Main {

	public static void main(String[] args) {
		
		Product p1 = new Product(102,"55 inch LED tv", "Samsung", 50000, "Electronics");
		
		//st-1: create a configuration object
		//Configuration cfg = new Configuration();
		//cfg = cfg.configure();
		
		
		//st-2: use the Configuration object to create a SessionFactory object
		//SessionFactory factory = cfg.buildSessionFactory();
		SessionFactory factory = HibernateUtil.getSessionFactory();
		
		
		//st-3:use the SessionFactory object to get the Session object
		Session s1 = factory.openSession();
		
		//st-4: use the session object to get Transaction object
		Transaction tx1 = s1.getTransaction();
		tx1.begin();
		
		//st-5: perform the database operation
		s1.save(p1);
		
		//st-6: commit the transaction
		tx1.commit();
		
		//st-7: close the session
		s1.close();
		
		/*
		Session session2 = factory.openSession();
		Transaction tx2 = session2.beginTransaction();
		//Query query = session2.createQuery("from Product p");
		//List<Product> products = query.list();
		Criteria criteria = session2.createCriteria(Product.class);
		List<Product> products = criteria.list();
		tx2.commit();
		for(Product p: products) {
			System.out.println(p);
		}
		session2.close()
		*/
		
		
		
		//st-8: close the session factory
		factory.close();
		
		
		
		
		

	}

}
