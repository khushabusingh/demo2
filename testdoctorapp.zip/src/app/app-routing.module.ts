import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { AdminListComponent } from './admin/admin-list/admin-list.component';
import { AdminLoginComponent } from './admin/admin-login/admin-login.component';
import { AdminComponent } from './admin/admin.component';
import { DoctorListComponent } from './doctor/doctor-list/doctor-list.component';
import { DoctorLoginComponent } from './doctor/doctor-login/doctor-login.component';
import { DoctorRegistrationComponent } from './doctor/doctor-registration/doctor-registration.component';
import { DoctorComponent } from './doctor/doctor.component';
import { HomeComponent } from './home/home.component';
import { PatientListComponent } from './patient/patient-list/patient-list.component';
import { PatientLoginComponent } from './patient/patient-login/patient-login.component';
import { PatientRegistrationComponent } from './patient/patient-registration/patient-registration.component';
import { PatientUpdateComponent } from './patient/patient-update/patient-update.component';
import { PatientComponent } from './patient/patient.component';
import { PolicyComponent } from './policy/policy.component';


const routes: Routes = [
  {path:'', component:HomeComponent},
  {path:'about',component:AboutComponent},
  {path:'admin',component:AdminComponent},
  {path:'adminlogin',component:AdminLoginComponent},
  {path:'adminlist',component:AdminListComponent},
  {path:'doctor',component:DoctorComponent},
  {path:'doctorlogin',component:DoctorLoginComponent},
  {path:'doctorregister' , component:DoctorRegistrationComponent},
  {path:'doctorlist' , component:DoctorListComponent},
  {path:'home' , component:HomeComponent},
  {path:'patient' , component:PatientComponent},
  {path:'patientregister',component:PatientRegistrationComponent},
  {path:'patientlist',component:PatientListComponent},
  {path:'patientlogin',component:PatientLoginComponent},
  {path:'policy',component:PolicyComponent},
 
 
 {path:'update/:pid',component:PatientUpdateComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {

 }
