import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Doctor } from '../doctor';
import { DoctorService } from '../doctor.service';


@Component({
  selector: 'app-doctor-login',
  templateUrl: './doctor-login.component.html',
  styleUrls: ['./doctor-login.component.css']
})
export class DoctorLoginComponent implements OnInit {
  
  constructor(private doctorservice : DoctorService , private router : Router ){

  }
    ngOnInit() {
     
    }
  doctor: Doctor = new Doctor("", "", "", "", "", "", "", "");


  loginDoctor(){
  this.doctorservice.loginDoctorfromRemote(this.doctor).subscribe(
    data =>{console.log("Response recieved");
    this.gotoDoctorDashboard();
  },
    error => console.log("Exception occured")
    )
  }

  gotoDoctorDashboard(){
    this.router.navigate(['/doctor'])
  }
}
