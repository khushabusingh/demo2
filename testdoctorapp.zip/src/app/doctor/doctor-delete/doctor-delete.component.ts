import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-doctor-delete',
  templateUrl: './doctor-delete.component.html',
  styleUrls: ['./doctor-delete.component.css']
})
export class DoctorDeleteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
