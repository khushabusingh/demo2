export class Doctor {
    constructor(
        public docid : string,
        public name: string, 
        public special: string,
        public qualify: string,
        public password: string,
        public phone: string,
        public address: string,
        public email: string,
  

    ) {}
}
