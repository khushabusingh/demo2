import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-doctor-update',
  templateUrl: './doctor-update.component.html',
  styleUrls: ['./doctor-update.component.css']
})
export class DoctorUpdateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
