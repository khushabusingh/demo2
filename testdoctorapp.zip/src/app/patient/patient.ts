export class Patient {
    constructor(
        public pid : string,
        public fname: string, 
        public lname: string,   
        public password: string,
        public phone: string,
        public address: string,
        public dateofbirth: string,
        public gender: string,
        public email: string,
  

    ) {}
}
