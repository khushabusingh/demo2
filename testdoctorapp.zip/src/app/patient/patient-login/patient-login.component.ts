import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Patient } from '../patient';

import { NgForm } from '@angular/forms';
import { PatientService } from '../patient.service';
@Component({
  selector: 'app-patient-login',
  templateUrl: './patient-login.component.html',
  styleUrls: ['./patient-login.component.css']
})
export class PatientLoginComponent implements OnInit {
  

constructor(private patientservice : PatientService , private router : Router ){

}
  ngOnInit() {
   
  }

  patient: Patient = new Patient("", "", "", "", "", "", "", "", "");


loginPatient(){
this.patientservice.loginPatientfromRemote(this.patient).subscribe(
  data =>{console.log("Response recieved");
  this.gotoPatientDashboard();
},
  error => console.log("Exception occured")
  )
}


gotoPatientDashboard(){
  this.router.navigate(['/patient'])
}
}
