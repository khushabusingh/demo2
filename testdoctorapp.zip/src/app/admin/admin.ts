export class Admin {
    constructor(
        public name: string,
         public password: string,
        public id: string,
        // public topic: string,
        // public timePreference: string,
        // public subscribe: boolean

    ) {}
}
